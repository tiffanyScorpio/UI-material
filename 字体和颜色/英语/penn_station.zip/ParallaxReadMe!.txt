This font was created by Parallax.  It is intended
for free distribution and use in any medium or format,
but is not to be re-sold.  I designed it
to make the world a better placem not to make your
wallet fatter.

Spruce up your CD jacket, website, or your term paper,
but please remember that this font, and all others designed
by Parallax, are (c)1999 David C. Lovelace.

Check out the Parallax website at:  http://www.umop.com

Feed the starving fontmaker.  Send donations to:

Dave Lovelace
P.O. Box 109
Broad Brook, CT
06016
USA

Donations of $10 or more will earn a free copy of "umop apisdn,"
a full-length CD filled with the wildest techno/prog metal ever.

I would also love to see any publications/sites you
used one or more of my fonts to design!  Please send me
a sample, or EMail links to me at:  dave@umop.com

Thanks for helping Parallax design the future!
